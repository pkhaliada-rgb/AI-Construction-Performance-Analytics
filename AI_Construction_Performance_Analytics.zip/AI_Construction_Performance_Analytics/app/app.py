import sys
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
APP_DIR = Path(__file__).resolve().parent

sys.path.append(str(ROOT))
sys.path.append(str(APP_DIR))

from pages import (
    dashboard,
    project_performance,
    delay_prediction,
    cost_prediction,
    resource_analytics,
    risk_assessment,
    gis_visualization,
    ml_analytics,
    reports,
    about,
)

st.set_page_config(
    page_title="BuildScope AI",
    page_icon="🏗️",
    layout="wide",
    initial_sidebar_state="expanded"
)

css_path = APP_DIR / "assets" / "style.css"
if css_path.exists():
    st.markdown(
        f"<style>{css_path.read_text(encoding='utf-8')}</style>",
        unsafe_allow_html=True
    )

if "page" not in st.session_state:
    st.session_state.page = "Dashboard"

with st.sidebar:
    st.markdown(
        """
        <div class="side-brand">
            <div class="brand-logo">🏗️</div>
            <div>
                <h2>BuildScope AI</h2>
                <p>Construction Intelligence</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    nav_items = {
        "Dashboard": "🏠",
        "Project Performance": "📊",
        "Delay Prediction": "⏱️",
        "Cost Prediction": "💰",
        "Resource Analytics": "👷",
        "Risk Assessment": "⚠️",
        "GIS Visualization": "🗺️",
        "ML Analytics": "🤖",
        "Reports": "📄",
        "About Project": "⚙️",
    }

    for page_name, icon in nav_items.items():
        if st.button(
            f"{icon}  {page_name}",
            key=f"nav_{page_name}",
            use_container_width=True
        ):
            st.session_state.page = page_name
            st.rerun()

st.markdown(
    """
    <div class="top-header">
        <div>
            <h3>Welcome back, Project Manager 👋</h3>
            <p>Indian metropolitan residential construction performance dashboard.</p>
        </div>
        <input placeholder="Search projects, contractors, metro cities..." />
    </div>
    """,
    unsafe_allow_html=True
)

page = st.session_state.page

if page == "Dashboard":
    dashboard.show()
elif page == "Project Performance":
    project_performance.show()
elif page == "Delay Prediction":
    delay_prediction.show()
elif page == "Cost Prediction":
    cost_prediction.show()
elif page == "Resource Analytics":
    resource_analytics.show()
elif page == "Risk Assessment":
    risk_assessment.show()
elif page == "GIS Visualization":
    gis_visualization.show()
elif page == "ML Analytics":
    ml_analytics.show()
elif page == "Reports":
    reports.show()
elif page == "About Project":
    about.show()