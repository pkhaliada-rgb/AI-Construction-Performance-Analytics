from pathlib import Path
import json, pandas as pd
ROOT=Path(__file__).resolve().parents[2]
PROCESSED_PATH=ROOT/"data"/"processed"/"processed_construction_projects.csv"
RAW_PATH=ROOT/"data"/"raw"/"construction_projects.csv"
OUTPUTS=ROOT/"outputs"

def load_data():
    if PROCESSED_PATH.exists(): return pd.read_csv(PROCESSED_PATH)
    if RAW_PATH.exists(): return pd.read_csv(RAW_PATH)
    return pd.DataFrame()
def load_metadata():
    p=OUTPUTS/"training_metadata.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
def load_delay_comparison():
    p=OUTPUTS/"delay_model_comparison.csv"; return pd.read_csv(p) if p.exists() else pd.DataFrame()
def load_risk_comparison():
    p=OUTPUTS/"risk_model_comparison.csv"; return pd.read_csv(p) if p.exists() else pd.DataFrame()
def load_cost_comparison():
    p=OUTPUTS/"cost_model_comparison.csv"; return pd.read_csv(p) if p.exists() else pd.DataFrame()
