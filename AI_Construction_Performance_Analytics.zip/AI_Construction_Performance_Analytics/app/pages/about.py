import streamlit as st
def show():
    st.markdown("## About Project")
    st.write("AI-Based Construction Performance Assessment and Predictive Analytics for Indian Metropolitan Residential Projects.")
    st.write("The system predicts delay status, risk level, and final construction cost using machine learning.")
