import streamlit as st

def show():
    st.markdown("## Cost Overrun Prediction")
    st.info("Use Delay Prediction module to enter project details and view predicted final cost.")
