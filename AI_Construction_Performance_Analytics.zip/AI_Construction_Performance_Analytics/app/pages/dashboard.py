import streamlit as st
import plotly.express as px
from components.data_loader import load_data, load_metadata


def metric_card(icon, title, value, sub, color):
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-icon" style="background:{color};">{icon}</div>
            <div>
                <p>{title}</p>
                <h2>{value}</h2>
                <span>{sub}</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )


def show():
    df = load_data()
    meta = load_metadata()

    if df.empty:
        st.warning("Dataset not found. Run: py src/generate_sample_data.py and py src/train_model.py")
        return

    delayed = int((df["delay_status"] != "On Schedule").sum()) if "delay_status" in df.columns else 0
    avg_spi = f"{df['schedule_performance_index'].mean():.2f}" if "schedule_performance_index" in df.columns else "-"
    avg_cpi = f"{df['cost_performance_index'].mean():.2f}" if "cost_performance_index" in df.columns else "-"
    delay_acc = f"{meta.get('delay_accuracy', 0) * 100:.2f}%"

    st.markdown(
        """
        <div class="hero">
            <div>
                <h1>Construction Performance Assessment</h1>
                <h3>AI-Based Predictive Analytics for Indian Metropolitan Residential Projects</h3>
                <p>
                    Monitor project costs, schedule performance, resource utilization,
                    risk levels, and construction progress through an AI-powered
                    decision-support dashboard.
                </p>
            </div>
            <div class="hero-art">🏗️🏢📊</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    c1, c2, c3, c4, c5 = st.columns(5)

    with c1:
        metric_card("🏗️", "Total Projects", f"{len(df):,}", "Portfolio records", "#ffedd5")
    with c2:
        metric_card("⏱️", "Delayed Projects", delayed, "Schedule risk indicator", "#fee2e2")
    with c3:
        metric_card("📈", "Average SPI", avg_spi, "Schedule Performance Index", "#dbeafe")
    with c4:
        metric_card("💰", "Average CPI", avg_cpi, "Cost Performance Index", "#dcfce7")
    with c5:
        metric_card("🎯", "Delay Accuracy", delay_acc, "Machine Learning accuracy", "#ede9fe")

    st.markdown("<br>", unsafe_allow_html=True)

    left, middle, right = st.columns([1.1, 1.1, 1.35])

    with left:
        st.markdown('<div class="chart-card"><h3>Delay Status Distribution</h3>', unsafe_allow_html=True)

        counts = df["delay_status"].value_counts().reset_index()
        counts.columns = ["Delay Status", "Projects"]

        fig = px.pie(
            counts,
            names="Delay Status",
            values="Projects",
            hole=0.58,
            color="Delay Status",
            color_discrete_map={
                "On Schedule": "#16a34a",
                "Minor Delay": "#facc15",
                "Major Delay": "#f97316",
                "Critical Delay": "#dc2626"
            }
        )

        fig.update_layout(
            height=330,
            margin=dict(l=10, r=10, t=10, b=10),
            font=dict(color="#0f172a")
        )

        st.plotly_chart(fig, width="stretch")
        st.markdown("</div>", unsafe_allow_html=True)

    with middle:
        st.markdown('<div class="chart-card"><h3>Average Cost by Metro City</h3>', unsafe_allow_html=True)

        city_cost = (
            df.groupby("metro_city")["actual_cost_cr"]
            .mean()
            .reset_index()
            .sort_values("actual_cost_cr", ascending=False)
        )

        fig = px.bar(
            city_cost,
            x="metro_city",
            y="actual_cost_cr",
            text=city_cost["actual_cost_cr"].round(1),
            labels={"metro_city": "Metro City", "actual_cost_cr": "Avg Cost (₹ Cr)"}
        )

        fig.update_traces(marker_color="#f97316", textposition="outside")

        fig.update_layout(
            height=330,
            margin=dict(l=10, r=10, t=10, b=10),
            plot_bgcolor="white",
            paper_bgcolor="white",
            font=dict(color="#0f172a")
        )

        st.plotly_chart(fig, width="stretch")
        st.markdown("</div>", unsafe_allow_html=True)

    with right:
        st.markdown(
            """
            <div class="chart-card">
                <h3>Metropolitan Project Risk Map</h3>
                <div class="project-map">
                    <div class="grid"></div>
                    <div class="pin" style="left:20%; top:32%;">📍</div>
                    <div class="pin" style="left:45%; top:58%;">📍</div>
                    <div class="pin" style="left:72%; top:27%;">📍</div>
                    <div class="pin" style="left:62%; top:50%;">📍</div>
                    <div class="pin" style="left:35%; top:72%;">📍</div>
                    <div class="legend">
                        <b>Risk Zones</b><br>
                        🟢 Low Risk<br>
                        🟡 Medium Risk<br>
                        🟠 High Risk<br>
                        🔴 Critical Risk
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    h1, h2 = st.columns([1, 1])

    with h1:
        st.markdown(
            """
            <div class="health-card">
                <h3>Project Health Summary</h3>

                <div class="health-row">
                    <span>Schedule Health 89%</span>
                    <div class="health-bar"><div class="health-fill" style="width:89%;"></div></div>
                </div>

                <div class="health-row">
                    <span>Cost Health 82%</span>
                    <div class="health-bar"><div class="health-fill" style="width:82%;"></div></div>
                </div>

                <div class="health-row">
                    <span>Quality Health 94%</span>
                    <div class="health-bar"><div class="health-fill" style="width:94%;"></div></div>
                </div>

                <div class="health-row">
                    <span>Resource Health 80%</span>
                    <div class="health-bar"><div class="health-fill" style="width:80%;"></div></div>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with h2:
        st.markdown('<div class="table-card">', unsafe_allow_html=True)
        st.markdown("### Top Risk Projects")

        risk_cols = [
            c for c in [
                "project_id",
                "metro_city",
                "risk_level",
                "delay_status",
                "progress_percent",
                "actual_cost_cr"
            ]
            if c in df.columns
        ]

        top_risk = df[df["risk_level"].isin(["High Risk", "Critical Risk"])].head(10)
        st.dataframe(top_risk[risk_cols], width="stretch", hide_index=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="table-card">', unsafe_allow_html=True)
    st.markdown("### Project Dataset Preview")

    show_cols = [
        c for c in [
            "project_id",
            "metro_city",
            "project_type",
            "contractor",
            "planned_cost_cr",
            "actual_cost_cr",
            "progress_percent",
            "delay_status",
            "risk_level"
        ]
        if c in df.columns
    ]

    st.dataframe(df[show_cols].head(10), width="stretch", hide_index=True)
    st.markdown("</div>", unsafe_allow_html=True)