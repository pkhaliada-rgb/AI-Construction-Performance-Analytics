import streamlit as st
from src.predict import predict_construction
def show():
    st.markdown("## Delay Prediction")
    c1,c2,c3=st.columns(3)
    with c1:
        metro_city=st.selectbox("Metro City",["Mumbai","Delhi","Bengaluru","Hyderabad","Chennai","Pune","Kolkata","Ahmedabad"])
        project_type=st.selectbox("Project Type",["Affordable Housing","Luxury Apartment","High-Rise Residential","Mixed-Use Residential","Gated Community"])
        contractor=st.selectbox("Contractor",["Alpha Build","Metro Infra","UrbanConstruct","Skyline Projects","Nirman Group","Prime Builders"])
        planned_cost_cr=st.number_input("Planned Cost (Cr)",value=120.0)
    with c2:
        material_cost_cr=st.number_input("Material Cost (Cr)",value=55.0)
        labor_cost_cr=st.number_input("Labor Cost (Cr)",value=20.0)
        equipment_cost_cr=st.number_input("Equipment Cost (Cr)",value=12.0)
        planned_duration_months=st.number_input("Planned Duration (Months)",value=24)
    with c3:
        actual_duration_months=st.number_input("Expected/Actual Duration (Months)",value=28)
        labor_count=st.number_input("Labor Count",value=320)
        equipment_count=st.number_input("Equipment Count",value=45)
        progress_percent=st.number_input("Progress %",value=70.0)
        quality_score=st.number_input("Quality Score",value=82.0)
        safety_score=st.number_input("Safety Score",value=85.0)
        resource_utilization_percent=st.number_input("Resource Utilization %",value=76.0)
        contractor_rating=st.number_input("Contractor Rating",value=4.0)
    spi=planned_duration_months/max(actual_duration_months,1)
    data={"metro_city":metro_city,"project_type":project_type,"contractor":contractor,"planned_cost_cr":planned_cost_cr,"material_cost_cr":material_cost_cr,"labor_cost_cr":labor_cost_cr,"equipment_cost_cr":equipment_cost_cr,"planned_duration_months":planned_duration_months,"actual_duration_months":actual_duration_months,"labor_count":labor_count,"equipment_count":equipment_count,"progress_percent":progress_percent,"quality_score":quality_score,"safety_score":safety_score,"resource_utilization_percent":resource_utilization_percent,"contractor_rating":contractor_rating,"schedule_performance_index":spi,"cost_performance_index":0.92,"latitude":19.07,"longitude":72.87}
    if st.button("Predict Construction Performance"):
        try:
            r=predict_construction(data); st.success(f"Delay Status: {r['delay_status']}"); st.info(f"Risk Level: {r['risk_level']} | Final Cost: ₹{r['predicted_final_cost_cr']} Cr")
        except Exception as e: st.error(str(e))
