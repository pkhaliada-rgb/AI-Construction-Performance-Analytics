import streamlit as st
import plotly.express as px
from components.data_loader import load_data
def show():
    st.markdown("## GIS Visualization")
    df=load_data()
    if df.empty: st.warning("Dataset not available."); return
    fig=px.scatter_map(df,lat="latitude",lon="longitude",color="risk_level",size="actual_cost_cr",zoom=4,height=560,title="Indian Metropolitan Construction Risk Map")
    st.plotly_chart(fig,width="stretch")
