import streamlit as st
import plotly.express as px
from components.data_loader import load_delay_comparison, load_risk_comparison, load_cost_comparison
def show():
    st.markdown("## ML Analytics")
    for title, df in [("Delay Models", load_delay_comparison()), ("Risk Models", load_risk_comparison()), ("Cost Models", load_cost_comparison())]:
        st.markdown(f"### {title}")
        if not df.empty:
            st.dataframe(df,width="stretch",hide_index=True)
            metric_cols=[c for c in df.columns if c!="Model"]
            st.plotly_chart(px.bar(df,x="Model",y=metric_cols,barmode="group"),width="stretch")
        else: st.warning("Train model first.")
