import streamlit as st
import plotly.express as px
from components.data_loader import load_data
def show():
    st.markdown("## Project Performance Assessment")
    df=load_data()
    if df.empty: st.warning("Dataset not available."); return
    st.plotly_chart(px.scatter(df,x="schedule_performance_index",y="cost_performance_index",color="risk_level",title="SPI vs CPI"),width="stretch")
    st.plotly_chart(px.histogram(df,x="progress_percent",color="delay_status",title="Progress Distribution"),width="stretch")
    st.dataframe(df.head(20),width="stretch",hide_index=True)
