import streamlit as st
from components.data_loader import load_data, load_delay_comparison, load_risk_comparison, load_cost_comparison
def show():
    st.markdown("## Reports")
    df=load_data()
    if not df.empty: st.download_button("Download Processed Dataset",df.to_csv(index=False),"processed_construction_projects.csv","text/csv")
    for name, data in [("Delay Report",load_delay_comparison()),("Risk Report",load_risk_comparison()),("Cost Report",load_cost_comparison())]:
        if not data.empty: st.download_button(f"Download {name}",data.to_csv(index=False),f"{name.lower().replace(' ','_')}.csv","text/csv")
