import streamlit as st
import plotly.express as px
from components.data_loader import load_data
def show():
    st.markdown("## Resource Analytics")
    df=load_data()
    if df.empty: st.warning("Dataset not available."); return
    st.plotly_chart(px.scatter(df,x="labor_count",y="resource_utilization_percent",color="delay_status",size="equipment_count",title="Labor vs Resource Utilization"),width="stretch")
    st.plotly_chart(px.box(df,x="metro_city",y="resource_utilization_percent",color="risk_level",title="Resource Utilization by Metro City"),width="stretch")
