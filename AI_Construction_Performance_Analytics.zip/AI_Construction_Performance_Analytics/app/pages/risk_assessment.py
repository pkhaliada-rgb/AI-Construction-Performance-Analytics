import streamlit as st
import plotly.express as px
from components.data_loader import load_data
def show():
    st.markdown("## Risk Assessment")
    df=load_data()
    if df.empty: st.warning("Dataset not available."); return
    counts=df["risk_level"].value_counts().reset_index(); counts.columns=["Risk Level","Projects"]
    st.plotly_chart(px.bar(counts,x="Risk Level",y="Projects",color="Risk Level",text="Projects"),width="stretch")
    st.dataframe(df[df["risk_level"].isin(["High Risk","Critical Risk"])].head(20),width="stretch",hide_index=True)
