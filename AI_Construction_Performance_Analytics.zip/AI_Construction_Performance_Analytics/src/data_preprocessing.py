from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw" / "construction_projects.csv"
PROCESSED_PATH = ROOT / "data" / "processed" / "processed_construction_projects.csv"

def load_dataset(path=RAW_PATH):
    path = Path(path)
    if not path.exists():
        from generate_sample_data import main
        main()
    return pd.read_csv(path)

def clean_dataset(df):
    df = df.copy()
    df.columns = [c.strip().lower().replace(" ","_") for c in df.columns]
    df = df.drop_duplicates()
    for col in df.columns:
        conv = pd.to_numeric(df[col], errors="coerce")
        if conv.notna().sum() > len(df)*0.70:
            df[col] = conv.fillna(conv.median())
        else:
            df[col] = df[col].astype(str)
            mode = df[col].mode()
            df[col] = df[col].replace("nan", mode.iloc[0] if not mode.empty else "Unknown")
    return df

def ensure_targets(df):
    if "schedule_performance_index" not in df.columns:
        df["schedule_performance_index"] = df["planned_duration_months"] / df["actual_duration_months"].clip(lower=1)
    if "cost_performance_index" not in df.columns:
        df["cost_performance_index"] = df["planned_cost_cr"] / df["actual_cost_cr"].clip(lower=1)
    if "delay_status" not in df.columns:
        delay = df["actual_duration_months"] - df["planned_duration_months"]
        df["delay_status"] = pd.cut(delay, [-999,0,3,8,999], labels=["On Schedule","Minor Delay","Major Delay","Critical Delay"]).astype(str)
    if "risk_level" not in df.columns:
        risk = (1-df["schedule_performance_index"].clip(0,1.2))*35 + (1-df["cost_performance_index"].clip(0,1.2))*30 + (100-df["quality_score"])*.2
        df["risk_level"] = pd.cut(risk, [-999,25,50,75,999], labels=["Low Risk","Medium Risk","High Risk","Critical Risk"]).astype(str)
    return df

def preprocess(path=RAW_PATH):
    df = ensure_targets(clean_dataset(load_dataset(path)))
    PROCESSED_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(PROCESSED_PATH,index=False)
    return df

if __name__ == "__main__":
    preprocess()
    print(f"Processed data saved: {PROCESSED_PATH}")
