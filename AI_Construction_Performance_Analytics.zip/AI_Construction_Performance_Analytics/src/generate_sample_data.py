from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw" / "construction_projects.csv"

def main(n=1000, seed=42):
    np.random.seed(seed)
    metros = ["Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Pune", "Kolkata", "Ahmedabad"]
    ptypes = ["Affordable Housing", "Luxury Apartment", "High-Rise Residential", "Mixed-Use Residential", "Gated Community"]
    contractors = ["Alpha Build", "Metro Infra", "UrbanConstruct", "Skyline Projects", "Nirman Group", "Prime Builders"]
    planned_duration = np.random.randint(10, 42, n)
    actual_duration = np.maximum((planned_duration * np.random.normal(1.08, 0.25, n)).astype(int), planned_duration - 3)
    planned_cost = np.random.uniform(20, 450, n)
    material_cost = planned_cost * np.random.uniform(0.38, 0.58, n)
    labor_cost = planned_cost * np.random.uniform(0.12, 0.25, n)
    equipment_cost = planned_cost * np.random.uniform(0.06, 0.16, n)
    actual_cost = np.maximum(planned_cost * (1 + ((actual_duration-planned_duration)/planned_duration)*0.22 + np.random.normal(0.04,0.08,n)), planned_cost*0.88)
    quality_score = np.random.uniform(55, 98, n)
    safety_score = np.random.uniform(50, 99, n)
    utilization = np.random.uniform(45, 98, n)
    progress = np.random.uniform(35, 100, n)
    spi = planned_duration / np.maximum(actual_duration, 1)
    cpi = planned_cost / np.maximum(actual_cost, 1)
    delay_months = actual_duration - planned_duration
    delay_status = pd.cut(delay_months, [-999,0,3,8,999], labels=["On Schedule","Minor Delay","Major Delay","Critical Delay"]).astype(str)
    risk_score = (1-np.clip(spi,0,1.2))*35 + (1-np.clip(cpi,0,1.2))*30 + (100-quality_score)*.2 + (100-safety_score)*.15 + (100-utilization)*.1
    risk_level = pd.cut(risk_score, [-999,25,50,75,999], labels=["Low Risk","Medium Risk","High Risk","Critical Risk"]).astype(str)
    df = pd.DataFrame({
        "project_id":[f"IN-METRO-{i:04d}" for i in range(1,n+1)],
        "metro_city":np.random.choice(metros,n),
        "project_type":np.random.choice(ptypes,n),
        "contractor":np.random.choice(contractors,n),
        "planned_cost_cr":np.round(planned_cost,2),
        "actual_cost_cr":np.round(actual_cost,2),
        "material_cost_cr":np.round(material_cost,2),
        "labor_cost_cr":np.round(labor_cost,2),
        "equipment_cost_cr":np.round(equipment_cost,2),
        "planned_duration_months":planned_duration,
        "actual_duration_months":actual_duration,
        "labor_count":np.random.randint(60,950,n),
        "equipment_count":np.random.randint(8,120,n),
        "progress_percent":np.round(progress,2),
        "quality_score":np.round(quality_score,2),
        "safety_score":np.round(safety_score,2),
        "resource_utilization_percent":np.round(utilization,2),
        "contractor_rating":np.round(np.random.uniform(2.5,5.0,n),2),
        "schedule_performance_index":np.round(spi,3),
        "cost_performance_index":np.round(cpi,3),
        "delay_status":delay_status,
        "risk_level":risk_level,
        "latitude":np.round(np.random.uniform(18.5,28.8,n),5),
        "longitude":np.round(np.random.uniform(72.5,88.5,n),5)
    })
    RAW_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(RAW_PATH,index=False)
    print(f"Sample dataset saved: {RAW_PATH}")

if __name__ == "__main__":
    main()
