from pathlib import Path
import joblib, pandas as pd
ROOT=Path(__file__).resolve().parents[1]
DELAY_MODEL=ROOT/"models"/"best_delay_classifier.pkl"
RISK_MODEL=ROOT/"models"/"best_risk_classifier.pkl"
COST_MODEL=ROOT/"models"/"best_cost_regressor.pkl"

def predict_construction(input_data):
    if not DELAY_MODEL.exists() or not RISK_MODEL.exists() or not COST_MODEL.exists():
        raise FileNotFoundError("Models not found. Run: py src/train_model.py")
    delay=joblib.load(DELAY_MODEL); risk=joblib.load(RISK_MODEL); cost=joblib.load(COST_MODEL)
    df=pd.DataFrame([input_data])
    return {
        "delay_status":str(delay.predict(df)[0]),
        "risk_level":str(risk.predict(df)[0]),
        "predicted_final_cost_cr":round(max(float(cost.predict(df)[0]),0),2),
        "delay_confidence":round(float(delay.predict_proba(df)[0].max())*100,2) if hasattr(delay,"predict_proba") else None,
        "risk_confidence":round(float(risk.predict_proba(df)[0].max())*100,2) if hasattr(risk,"predict_proba") else None
    }
