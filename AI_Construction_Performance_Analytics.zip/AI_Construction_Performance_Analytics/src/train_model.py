from pathlib import Path
import json, joblib, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, r2_score, mean_absolute_error, mean_squared_error
from data_preprocessing import preprocess

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "models"; OUTPUTS = ROOT / "outputs"
DELAY_TARGET="delay_status"; RISK_TARGET="risk_level"; COST_TARGET="actual_cost_cr"

def prep(X):
    return ColumnTransformer([
        ("num", StandardScaler(), X.select_dtypes(include="number").columns.tolist()),
        ("cat", OneHotEncoder(handle_unknown="ignore"), X.select_dtypes(exclude="number").columns.tolist())
    ])

def train_clf(X_train, X_test, y_train, y_test, suffix):
    models = {f"Random Forest {suffix}":RandomForestClassifier(n_estimators=150,random_state=42),
              f"Decision Tree {suffix}":DecisionTreeClassifier(random_state=42)}
    best_acc=-1; best_pipe=None; best_name=""; rows=[]; labels=sorted(y_train.unique())
    best_cm=None
    for name, model in models.items():
        pipe=Pipeline([("preprocessor",prep(X_train)),("model",model)])
        pipe.fit(X_train,y_train); pred=pipe.predict(X_test)
        acc=accuracy_score(y_test,pred)
        rows.append({"Model":name,"Accuracy":acc,"Precision":precision_score(y_test,pred,average="weighted",zero_division=0),"Recall":recall_score(y_test,pred,average="weighted",zero_division=0),"F1 Score":f1_score(y_test,pred,average="weighted",zero_division=0)})
        if acc>best_acc:
            best_acc=acc; best_pipe=pipe; best_name=name; best_cm=confusion_matrix(y_test,pred,labels=labels)
    return best_pipe,best_name,best_acc,rows,best_cm,labels

def train():
    df=preprocess()
    X=df.drop(columns=[c for c in ["project_id", DELAY_TARGET, RISK_TARGET, COST_TARGET] if c in df.columns])
    yd=df[DELAY_TARGET]; yr=df[RISK_TARGET]; yc=df[COST_TARGET]
    strat=yd if yd.value_counts().min()>=2 else None
    Xtr,Xte,ydtr,ydte,yrtr,yrte,yctr,ycte=train_test_split(X,yd,yr,yc,test_size=.2,random_state=42,stratify=strat)
    delay_pipe,delay_name,delay_acc,delay_rows,delay_cm,delay_labels = train_clf(Xtr,Xte,ydtr,ydte,"Delay Classifier")
    risk_pipe,risk_name,risk_acc,risk_rows,risk_cm,risk_labels = train_clf(Xtr,Xte,yrtr,yrte,"Risk Classifier")
    best_r2=-999; best_reg=None; best_reg_name=""; cost_rows=[]
    for name,model in {"Random Forest Cost Regressor":RandomForestRegressor(n_estimators=150,random_state=42),"Decision Tree Cost Regressor":DecisionTreeRegressor(random_state=42)}.items():
        pipe=Pipeline([("preprocessor",prep(Xtr)),("model",model)])
        pipe.fit(Xtr,yctr); pred=pipe.predict(Xte); r2=r2_score(ycte,pred)
        cost_rows.append({"Model":name,"R2 Score":r2,"MAE":mean_absolute_error(ycte,pred),"RMSE":mean_squared_error(ycte,pred)**0.5})
        if r2>best_r2: best_r2=r2; best_reg=pipe; best_reg_name=name
    MODELS.mkdir(exist_ok=True); OUTPUTS.mkdir(exist_ok=True)
    joblib.dump(delay_pipe,MODELS/"best_delay_classifier.pkl")
    joblib.dump(risk_pipe,MODELS/"best_risk_classifier.pkl")
    joblib.dump(best_reg,MODELS/"best_cost_regressor.pkl")
    pd.DataFrame(delay_rows).to_csv(OUTPUTS/"delay_model_comparison.csv",index=False)
    pd.DataFrame(risk_rows).to_csv(OUTPUTS/"risk_model_comparison.csv",index=False)
    pd.DataFrame(cost_rows).to_csv(OUTPUTS/"cost_model_comparison.csv",index=False)
    pd.DataFrame(delay_cm,index=delay_labels,columns=delay_labels).to_csv(OUTPUTS/"delay_confusion_matrix.csv")
    pd.DataFrame(risk_cm,index=risk_labels,columns=risk_labels).to_csv(OUTPUTS/"risk_confusion_matrix.csv")
    meta={"best_delay_classifier":delay_name,"delay_accuracy":round(float(delay_acc),4),"best_risk_classifier":risk_name,"risk_accuracy":round(float(risk_acc),4),"best_cost_regressor":best_reg_name,"cost_r2":round(float(best_r2),4),"feature_columns":X.columns.tolist()}
    (OUTPUTS/"training_metadata.json").write_text(json.dumps(meta,indent=4),encoding="utf-8")
    print(f"Best delay model: {delay_name} | Accuracy: {delay_acc:.4f}")
    print(f"Best risk model: {risk_name} | Accuracy: {risk_acc:.4f}")
    print(f"Best cost model: {best_reg_name} | R2: {best_r2:.4f}")

if __name__=="__main__":
    train()
